#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
//Anton Dubovoi

// Define a structure to hold information about each waste item
struct WasteItem {
    std::string name;           // Unique identifier for the waste item
    int storageCost;            // Penalty cost if the item is not incinerated
    int incinerationTime;       // Time required to incinerate the item
};

int main(int argc, char* argv[]) {
    // Check command-line arguments for proper usage
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " input_file [-print]" << std::endl;
        return 1;
    }

    // Open the file specified by the first command line argument
    std::ifstream file(argv[1]);
    if (!file) {
        std::cerr << "Error: Could not open file " << argv[1] << std::endl;
        return 1;
    }

    // Check for the -print option to decide whether to print stored items
    bool printStoredItems = (argc > 2 && std::string(argv[2]) == "-print");

    int n, t;  // n is the number of items, t is the total available time
    file >> n >> t;

    // Read all waste items from the file
    std::vector<WasteItem> items(n);
    for (int i = 0; i < n; i++) {
        file >> items[i].name >> items[i].storageCost >> items[i].incinerationTime;
    }

    // Dynamic Programming (DP) array to keep track of the minimum penalty cost achievable
    std::vector<int> dp(t + 1, 0);  // Initialize DP array with zero

    // Calculate the total penalty cost if no items are incinerated
    int totalStorageCost = 0;
    for (const auto& item : items) {
        totalStorageCost += item.storageCost;
    }

    // Main DP logic to minimize storage cost
    for (int i = 0; i < n; i++) {
        for (int j = t; j >= items[i].incinerationTime; j--) {
            dp[j] = std::max(dp[j], dp[j - items[i].incinerationTime] + items[i].storageCost);
        }
    }

    // Calculate the minimum possible total storage cost
    int maxReduction = dp[t];
    int minimumStorageCost = totalStorageCost - maxReduction;
    std::cout << "TOTAL PENALTY: " << minimumStorageCost << std::endl;

    // If the -print flag is set, determine and print the items that are stored
    if (printStoredItems) {
        std::vector<bool> incinerated(n, false);
        int remainingTime = t;
        for (int i = n - 1; i >= 0 && remainingTime > 0; i--) {
            if (remainingTime >= items[i].incinerationTime && dp[remainingTime] == dp[remainingTime - items[i].incinerationTime] + items[i].storageCost) {
                incinerated[i] = true;
                remainingTime -= items[i].incinerationTime;
            }
        }

        std::cout << "ITEMS STORED: ";
        for (int i = 0; i < n; i++) {
            if (!incinerated[i]) {
                std::cout << items[i].name << " ";
            }
        }
        std::cout << std::endl;
    }

    return 0;
}
