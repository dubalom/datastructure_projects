#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <string>
#include <map>

//Anton Dubovoi

using namespace std;

struct Edge {
    string src, dest;
    int weight;
};

struct Graph {
    vector<Edge> edges;
};

struct DisjointSets {
    map<string, string> parent;
    map<string, int> rank;
    
    // Find the root of the set in which element u is present
    string find(string u) {
        if (parent[u] != u)
            parent[u] = find(parent[u]);
        return parent[u];
    }

    // Union by rank of two sets
    void unionSet(string u, string v) {
        string rootU = find(u);
        string rootV = find(v);
        if (rootU != rootV) {
            if (rank[rootU] > rank[rootV])
                parent[rootV] = rootU;
            else if (rank[rootU] < rank[rootV])
                parent[rootU] = rootV;
            else {
                parent[rootV] = rootU;
                rank[rootU]++;
            }
        }
    }
};

int KruskalMST(Graph& graph) {
    int mst_weight = 0;
    vector<Edge> edges = graph.edges;
    DisjointSets ds;

    // Sort edges by ascending weight
    sort(edges.begin(), edges.end(), [](const Edge &a, const Edge &b) {
        return a.weight < b.weight;
    });

    // Initialize disjoint sets
    for (auto& edge : edges) {
        ds.parent[edge.src] = edge.src;
        ds.parent[edge.dest] = edge.dest;
        ds.rank[edge.src] = 0;
        ds.rank[edge.dest] = 0;
    }

    // Iterate over edges and select those which don't form a cycle
    for (Edge& edge : edges) {
        string root1 = ds.find(edge.src);
        string root2 = ds.find(edge.dest);

        if (root1 != root2) {
            mst_weight += edge.weight;
            ds.unionSet(root1, root2);
        }
    }

    return mst_weight;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cout << "Usage: " << argv[0] << " <filename>\n";
        return 1;
    }

    ifstream file(argv[1]);
    if (!file) {
        cout << "Failed to open file.\n";
        return 1;
    }

    Graph g;
    string u, v;
    int w;

    while (file >> u >> v >> w) {
        Edge e{u, v, w};
        g.edges.push_back(e);
    }

    file.close();

    int mstWeight = KruskalMST(g);
    cout << mstWeight << endl;

    return 0;
}