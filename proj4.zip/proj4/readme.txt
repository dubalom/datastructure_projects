Anton Dubovoi

5 April 2024

Mac OS, Visual Studio Code 2

The program finds the closest pair of points in a set by using a divide-and-conquer algorithm. It starts by reading points from a file and sorting them by their x-coordinates. Then, it recursively divides the points into two halves, finds the closest pair in each half, and merges the results. For points near the dividing line, it checks for closer pairs within a specifically created strip, optimizing the process to reduce complexity from O(n²) to O(n log n). Finally, it outputs the minimum distance and the details of the closest pair.