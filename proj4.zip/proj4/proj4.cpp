#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <string>
#include <limits>

//Anton Dubovoi
//4 April
//Project 4

using namespace std;

struct Point {
    string name;
    double x, y;
};

// Function to calculate distance between two points
double distance(const Point& a, const Point& b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

// Divide and Conquer function to find the closest pair of points
pair<double, pair<Point, Point>> closestPair(vector<Point>::iterator it, size_t n) {
    if (n <= 3) {
        // Base case: compute distance directly
        double minDist = numeric_limits<double>::max();
        pair<Point, Point> minPair;
        for (size_t i = 0; i < n; ++i)
            for (size_t j = i + 1; j < n; ++j) {
                double dist = distance(*(it + i), *(it + j));
                if (dist < minDist) {
                    minDist = dist;
                    minPair = make_pair(*(it + i), *(it + j));
                }
            }
        return make_pair(minDist, minPair);
    }

    // Divide
    size_t mid = n / 2;
    auto midPoint = *(it + mid);

    // Conquer
    auto left = closestPair(it, mid);
    auto right = closestPair(it + mid, n - mid);

    // Combine
    auto result = (left.first < right.first) ? left : right;

    // Check for points close to the dividing line and within the minimum distance found so far
    vector<Point> strip;
    for (size_t i = 0; i < n; i++)
        if (abs((it + i)->x - midPoint.x) < result.first)
            strip.push_back(*(it + i));

    sort(strip.begin(), strip.end(), [](const Point& a, const Point& b) {
        return a.y < b.y;
    });

    // Find the closest pair in the strip
    for (size_t i = 0; i < strip.size(); ++i)
        for (size_t j = i + 1; j < strip.size() && (strip[j].y - strip[i].y) < result.first; ++j) {
            double dist = distance(strip[i], strip[j]);
            if (dist < result.first) {
                result.first = dist;
                result.second = make_pair(strip[i], strip[j]);
            }
        }

    return result;
}

// Function to read points from file and initialize the process
void findClosestPair(const string& filename) {
    ifstream file(filename);
    if (!file) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    int n;
    file >> n;

    vector<Point> points(n);
    for (int i = 0; i < n; ++i) {
        file >> points[i].name >> points[i].x >> points[i].y;
    }

    // Sort points by x-coordinate
    sort(points.begin(), points.end(), [](const Point& a, const Point& b) {
        return a.x < b.x;
    });

    // Find the closest pair
    auto result = closestPair(points.begin(), n);

    cout << "Min Distance: " << result.first << endl;
    cout << "Between [" << result.second.first.name << ":(" << result.second.first.x << result.second.first.y << ")] and [";
    cout << result.second.second.name << ":(" << result.second.second.x << result.second.second.y << ")]" << endl;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <filename>" << endl;
        return 1;
    }

    string filename = argv[1];
    findClosestPair(filename);

    return 0;
}