Anton Dubovoi

20 March 2024

Mac OS, Visual Studio Code 2

This C++ program is designed to read a list of items with associated costs and deadlines from a file, then compute and output the minimum total storage cost.The main function orchestrates the flow: it reads the input filename from the command-line arguments, retrieves the data, computes the minimum storage costs using two different strategies, and then outputs the smaller of the two computed costs.