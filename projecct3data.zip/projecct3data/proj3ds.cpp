#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
#include <tuple>

//Anton Dubovoi

//20 March 20204

using namespace std;

// Defines a custom comparator for sorting tuples by their second element in non-increasing order
// or by their first element if their second elements are equal.
class tuplecompare {
public:
    bool operator()(const tuple<int, int>& lo, const tuple<int, int>& ro)const{
        return get<1>(lo)> get<1>(ro) || get<0>(lo) == get<0>(ro) && get<1>(lo) < get<1>(ro);
    }
};
// Defines another custom comparator for sorting tuples by their second element in non-decreasing order
// or by their first element if their second elements are equal.
class tuplecompare2 {
public:
    bool operator()(const tuple<int, int>& lo, const tuple<int, int>& ro)const{
        return get<1>(lo) < get<1>(ro) || get<1>(lo) == get<1>(ro) && get<0>(lo) > get<0>(ro);
    }
};

// Function to read the data from the file and store it in a vector
vector<tuple<int, int>> readData(const string& filename) {
    ifstream file(filename);
    vector<tuple<int, int>> wasteItems;
    string id;
    int cost, deadline;

    while (file >> id >> cost >> deadline) {
        wasteItems.push_back(make_tuple(cost, deadline));
    }

    return wasteItems;
}

// Function to compute the minimum total storage cost
int minStorageCost(vector<tuple<int, int>>& wasteItems) {
    // Sort the items based on their deadline and cost
    sort(wasteItems.begin(), wasteItems.end(), tuplecompare());
    int totalCost = 0, days = 0;

    for (auto& item : wasteItems) {
        int deadline = get<1>(item);
        int cost = get<0>(item);

        // If we've reached the deadline, remove the item with the highest cost
        if (days < deadline) {
            days++;
        }
        else{
            totalCost+=cost;
        }
    }


    return totalCost;
}
int minStorageCost2(vector<tuple<int, int>>& wasteItems) {
    // Sort the items based on their deadline and cost
    sort(wasteItems.begin(), wasteItems.end(), tuplecompare2());
    int totalCost = 0, days = 0;

    for (auto& item : wasteItems) {
        int deadline = get<1>(item);
        int cost = get<0>(item);

        // If we've reached the deadline, remove the item with the highest cost
        if (days < deadline) {
            days++;
        }
        else{
            totalCost+=cost;
        }
    }


    return totalCost;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <input_file>" << endl;
        return 1;
    }

    string filename = argv[1];
    auto wasteItems = readData(filename);
    int c1 = minStorageCost(wasteItems);
    int c2 = minStorageCost2(wasteItems);
    cout << min(c1,c2) << endl;// Outputs the minimum of the two computed costs.

    return 0;
}