#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <algorithm>
using namespace std;


void bubbleSort(string* data, int size);
void heapify(string arr[], int n, int i);
void bubbleSort(string* data, int size);
void merge(string arr[], int low, int mid, int high);
void mergeSort(string arr[], int low, int high);
int partition( string arr[], int low, int high);
void quickSort( string arr[], int low, int high);
void heapSort(string arr[], int n);

string* readData(istream& in, int* size);

int main(int argc, char** argv)
{
    if((argc != 3 && argc != 4) || (argc == 4 && strcmp(argv[3],"-print")!=0))
    {
        cout<< "Usage:\nproj1 <filename> bubble|merge|quick|heap|sys [-print]\n";
        return 1;
    }

    ifstream in(argv[1]);
    if(!in)
    {
        cout<<"not valid filename\n";
        return 1;
    }
    int size;
    string* data = readData(in,&size); 
    
    in.close();

    if(!data)
    {
        cout<<"unable to read data\n";
        return 1;
    }
   
    if(strcmp("bubble",argv[2])== 0)
    {
        bubbleSort(data,size);
    }
    else if (strcmp("heap",argv[2])== 0)
    {
        heapSort(data,size);
    }
    else if (strcmp("merge",argv[2])== 0)
    {
        mergeSort(data,0,size-1);
    }
    else if (strcmp("quick",argv[2])== 0)
    {
        quickSort(data,0,size);
    }
    else if(strcmp("sys",argv[2])== 0){
        sort(data, data+size);
    }



    if(argc == 4 )
    {
        for(int i = 0; i < size; i++)
        {
            cout<<data[i]<<"\n";
        }
    }
    return 0;
}

string* readData(istream& in, int* size)
{
    in >> *size;
    if(!in)
        return nullptr;
    string* result = new string[*size+1];
    getline(in, result[0]);
    for(int i = 0; i < *size; i++)
    {
        getline(in, result[i]);
        if(!in)
        {
            delete[] result;
            return nullptr;
        }
    }
    result[*size] = "";
    return result;
}

void bubbleSort(string* data, int size)
{
    for(int i = 0; i < size; i++){
        for(int j = 0; j < size - i - 1; j++){
            if(data[j]>data[j+1]){
                string temp = data[j];
                data[j] = data[j+1];
                data[j+1] = temp;
            }
        }
    }
}
void heapify(string arr[], int n, int i)
{
    int largest = i;//initialize the largest element as the subtree.
    int left = 2*i + 1;// left child equals 2*i +1
    int right = 2*i + 2;// right child equals 2*i +2
    //if left child is the largest, then it will become the new root.
    if (left < n && arr[left] > arr[largest])
        largest = left;
    //if right child is the larges, then it will become the new root.
    if (right < n && arr[right] > arr[largest])
        largest = right;
    //if the largest is not the root.
    if (largest != i)
    {   //heapify the modified subtree.
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}
//main function for heapSort.
void heapSort(string arr[], int n)
{   //rearrange the array.
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);
    //taking elements from the heap.
    for (int i=n-1; i>=0; i--)
    {
        swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}
//function to merge two subarrays
void merge(string arr[], int low, int mid, int high) {
  
  int len1 = mid - low + 1;
  int len2 = high - mid;
    //create temporary arrays.
  string leftArr[len1], rightArr[len2];
    
    //copy data to the two temporary arrays.
  for (int i = 0; i < len1; i++)
    leftArr[i] = arr[low + i];
  for (int j = 0; j < len2; j++)
    rightArr[j] = arr[mid + 1 + j];

  int i, j, z;
  i = 0;
  j = 0;
  z = low;

  while (i < len1 && j < len2) {
    if (leftArr[i] <= rightArr[j]) {
      arr[z] = leftArr[i];
      i++;
    } else {
      arr[z] = rightArr[j];
      j++;
    }
    z++;
  }
//copy the remaining elements of left array.
  while (i < len1) {
    arr[z] = leftArr[i];
    i++;
    z++;
  }
//copy the remaining elements of right array.
  while (j < len2) {
    arr[z] = rightArr[j];
    j++;
    z++;
  }
}
//main function for mergeSort.
void mergeSort(string arr[], int low, int high) {
  if (low < high) {
    int mid = low + (high - low) / 2;
      
    //merge sort first and second half.
    mergeSort(arr, low, mid);
    mergeSort(arr, mid + 1, high);

    merge(arr, low, mid, high);
  }
}
//function for partition.
int partition( string arr[], int low, int high)
{
    string pivot= arr[low];//first element as the pivot for the array.
    int i= low, j= high;//variables for the initial and last index of the array.

    do {

        do{i++;} while(i<j && arr[i]<= pivot);//move i as long as its less or equal to the pivot.
        do{j--;} while(arr[j] > pivot);//move j as long as its greather than the pivot.

        /*if i is less than j, swap arr[i] and arr[j]*/
        if (i<j)
        {
            string temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }


    } while (i<j);//perform everything above if i is less than j.
    
    //swap the pivot with arr[j].
    string temp = arr[low];
    arr[low] = arr[j];
    arr[j] = temp;
    return j;

}
//function for quick sort.
void quickSort( string arr[], int low, int high)
{
    int j;
    //if low is less than high.
    if(low < high)
    {
        j=partition(arr,low,high);//perform partition function and store it in j(partitioning position).
        quickSort(arr, low, j);//quick sort from low to j.
        quickSort(arr, j+1, high);//quick sort from the element next to partitioning position to high.


    }
}