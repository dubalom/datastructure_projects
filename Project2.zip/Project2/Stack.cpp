// Your implementation of the Stack class goes here!!!!

#include "Stack.hpp"

#include <iostream>

using namespace std;

bool Stack::isEmpty() const{
    return empty();
}
void Stack::push(ActivationRecord *newAR){
    push_back(newAR);
}
ActivationRecord* Stack::pop(){
    if (isEmpty())
    {
        return nullptr;
    }
    auto b = back(); 
    pop_back();
    return b;
    
}
ActivationRecord* Stack::top() const{
    if(isEmpty()){
        return nullptr;
    }
    return back();
}
ActivationRecord* Stack::peek() const{
    if(isEmpty()){
        return nullptr;
    }
    auto iter = rbegin();
    iter++;
    if(iter != rend()){
        return *iter;
    }
    return nullptr;
}
std::ostream& operator<<(std::ostream &os, const Stack &s){
    for(auto iter = s.rbegin(); iter != s.rend(); iter++){
        os << **iter;
    }
    return os;
}

